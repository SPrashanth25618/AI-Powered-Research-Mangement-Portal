import { Routes, Route, Navigate } from "react-router-dom";
import { useAuth } from "./auth/AuthProvider";
import { supabase } from "./supabase/client";
import { useEffect, useState } from "react";

import SignIn from "./auth/SignIn";
import SignUp from "./auth/SignUp";

import StudentDashboard from "./dashboards/StudentDashboard";
import FacultyDashboard from "./dashboards/FacultyDashboard";
import HODDashboard from "./dashboards/HODDashboard";
import AdminDashboard from "./dashboards/AdminDashboard";

import StudentSubmissions from "./components/StudentSubmissions";

export default function App() {
  const { user } = useAuth();
  const [role, setRole] = useState(null);

  useEffect(() => {
    if (!user) return;

    supabase
      .from("users")
      .select("role")
      .eq("id", user.id)
      .single()
      .then(({ data }) => {
        if (data) setRole(data.role);
      });
  }, [user]);

  if (user && !role) {
    return <div className="p-10">Loading profile…</div>;
  }

  return (
    <Routes>
      {/* ---------- PUBLIC ---------- */}
      {!user && (
        <>
          <Route path="/" element={<SignIn />} />
          <Route path="/signup" element={<SignUp />} />
          <Route path="*" element={<Navigate to="/" />} />
        </>
      )}

      {/* ---------- STUDENT ---------- */}
      {user && role === "STUDENT" && (
        <>
          <Route path="/student" element={<StudentDashboard />} />
          <Route path="/student/submissions" element={<StudentSubmissions />} />
          <Route path="*" element={<Navigate to="/student" />} />
        </>
      )}

      {/* ---------- FACULTY ---------- */}
      {user && role === "FACULTY" && (
        <>
          <Route path="/faculty" element={<FacultyDashboard />} />
          <Route path="*" element={<Navigate to="/faculty" />} />
        </>
      )}

      {/* ---------- HOD ---------- */}
      {user && role === "HOD" && (
        <>
          <Route path="/hod" element={<HODDashboard />} />
          <Route path="*" element={<Navigate to="/hod" />} />
        </>
      )}

      {/* ---------- ADMIN ---------- */}
      {user && role === "ADMIN" && (
        <>
          <Route path="/admin" element={<AdminDashboard />} />
          <Route path="*" element={<Navigate to="/admin" />} />
        </>
      )}
    </Routes>
  );
}
