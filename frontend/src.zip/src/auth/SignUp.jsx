import { useState, useEffect } from "react";
import { supabase } from "../supabase/client";
import { Link } from "react-router-dom";

export default function SignUp() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [departments, setDepartments] = useState([]);
  const [departmentId, setDepartmentId] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    supabase.from("departments").select("*").then(({ data }) => {
      setDepartments(data);
    });
  }, []);

  const handleSignup = async () => {
    if (!departmentId) {
      setError("Please select department");
      return;
    }

    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          full_name: name,
          department_id: departmentId
        }
      }
    });

    if (error) setError(error.message);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-100">
      <div className="bg-white p-8 w-96 rounded shadow-lg">
        <h2 className="text-2xl font-bold mb-4 text-center">Student Signup</h2>

        {error && <p className="text-red-600 text-sm">{error}</p>}

        <input className="border p-2 w-full mb-3" placeholder="Full Name" onChange={e=>setName(e.target.value)} />
        <input className="border p-2 w-full mb-3" placeholder="Email" onChange={e=>setEmail(e.target.value)} />
        <input type="password" className="border p-2 w-full mb-3" placeholder="Password" onChange={e=>setPassword(e.target.value)} />

        <select
          className="border p-2 w-full mb-4"
          onChange={e => setDepartmentId(e.target.value)}
        >
          <option value="">Select Department</option>
          {departments.map(d => (
            <option key={d.id} value={d.id}>{d.name}</option>
          ))}
        </select>

        <button onClick={handleSignup} className="bg-green-600 text-white w-full py-2 rounded">
          Sign Up
        </button>

        <p className="text-center mt-4 text-sm">
          Already have an account? <Link to="/" className="text-blue-600">Sign In</Link>
        </p>
      </div>
    </div>
  );
}
