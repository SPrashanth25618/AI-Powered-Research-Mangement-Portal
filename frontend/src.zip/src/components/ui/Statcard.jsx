import { TrendingUp, TrendingDown, Minus } from "lucide-react";

export default function StatCard({ 
  label, 
  value, 
  icon: Icon,
  trend,
  trendValue,
  color = "emerald"
}) {
  const colorClasses = {
    emerald: {
      bg: "bg-emerald-100",
      text: "text-emerald-600",
      gradient: "from-emerald-500 to-teal-600"
    },
    blue: {
      bg: "bg-blue-100",
      text: "text-blue-600",
      gradient: "from-blue-500 to-cyan-600"
    },
    purple: {
      bg: "bg-purple-100",
      text: "text-purple-600",
      gradient: "from-purple-500 to-pink-600"
    },
    amber: {
      bg: "bg-amber-100",
      text: "text-amber-600",
      gradient: "from-amber-500 to-orange-600"
    }
  };

  const colors = colorClasses[color] || colorClasses.emerald;

  const getTrendIcon = () => {
    if (trend === "up") return <TrendingUp className="w-4 h-4" />;
    if (trend === "down") return <TrendingDown className="w-4 h-4" />;
    return <Minus className="w-4 h-4" />;
  };

  const getTrendColor = () => {
    if (trend === "up") return "text-emerald-600 bg-emerald-50";
    if (trend === "down") return "text-red-600 bg-red-50";
    return "text-gray-600 bg-gray-50";
  };

  return (
    <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6 hover:shadow-lg transition-all duration-300 group">
      <div className="flex items-start justify-between mb-4">
        {/* Icon */}
        {Icon && (
          <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${colors.gradient} flex items-center justify-center shadow-md`}>
            <Icon className="w-6 h-6 text-white" />
          </div>
        )}
        
        {/* Trend Badge */}
        {trend && trendValue && (
          <div className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold ${getTrendColor()}`}>
            {getTrendIcon()}
            <span>{trendValue}</span>
          </div>
        )}
      </div>

      {/* Label */}
      <p className="text-sm font-medium text-gray-500 mb-1">{label}</p>

      {/* Value */}
      <h2 className="text-3xl font-bold text-gray-900 group-hover:text-emerald-600 transition-colors">
        {value}
      </h2>

      {/* Decorative Line */}
      <div className="mt-4 h-1 w-0 group-hover:w-full bg-gradient-to-r from-emerald-500 to-teal-500 rounded-full transition-all duration-500" />
    </div>
  );
}