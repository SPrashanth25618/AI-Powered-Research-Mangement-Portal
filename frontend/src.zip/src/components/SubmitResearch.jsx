import { useState } from "react";
import { supabase } from "../supabase/client";
import { Upload, FileText, CheckCircle, AlertCircle, Loader2 } from "lucide-react";

export default function SubmitResearch({ onSuccess }) {
  const [title, setTitle] = useState("");
  const [abstract, setAbstract] = useState("");
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState("");
  const [msgType, setMsgType] = useState("");

  const handleSubmit = async () => {
    if (!title || !file) {
      setMsg("Title and PDF are required");
      setMsgType("error");
      return;
    }

    setLoading(true);
    setMsg("");

    try {
      const { data: { user } } = await supabase.auth.getUser();

      const { data: profile, error: profileError } = await supabase
        .from("users")
        .select("department_id")
        .eq("id", user.id)
        .single();

      if (profileError) throw profileError;

      const filePath = `${user.id}/${Date.now()}_${file.name}`;
      const { error: uploadError } = await supabase.storage
        .from("research-pdfs")
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from("research-pdfs")
        .getPublicUrl(filePath);

      const { error: insertError } = await supabase
        .from("research_projects")
        .insert({
          title,
          abstract,
          student_id: user.id,
          department_id: profile.department_id,
          pdf_url: publicUrl,
          status: "SUBMITTED"
        });

      if (insertError) throw insertError;

      setMsg("Research submitted successfully!");
      setMsgType("success");
      setTitle("");
      setAbstract("");
      setFile(null);
      if (onSuccess) onSuccess(); // Refresh stats in parent
    } catch (err) {
      console.error(err);
      setMsg(err.message || "Submission failed");
      setMsgType("error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full">
      {/* Feedback Messages */}
      {msg && (
        <div className={`flex items-center gap-3 p-4 mb-6 rounded-lg border shadow-sm animate-in fade-in slide-in-from-top-2 ${
          msgType === "success" 
            ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-600" 
            : "bg-destructive/10 border-destructive/20 text-destructive"
        }`}>
          {msgType === "success" ? <CheckCircle className="w-5 h-5" /> : <AlertCircle className="w-5 h-5" />}
          <p className="text-sm font-medium">{msg}</p>
        </div>
      )}

      {/* Form Container */}
      <div className="space-y-6">
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">Project Title</label>
            <input
              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
              placeholder="Enter the full title of your research"
              value={title}
              onChange={e => setTitle(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">Abstract</label>
            <textarea
              className="flex min-h-[120px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
              placeholder="Briefly summarize your findings..."
              value={abstract}
              onChange={e => setAbstract(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">Research PDF</label>
            <div className="flex items-center justify-center w-full">
              <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed border-input rounded-lg cursor-pointer bg-accent/50 hover:bg-accent transition-colors">
                <div className="flex flex-col items-center justify-center pt-5 pb-6">
                  <Upload className="w-8 h-8 text-muted-foreground mb-2" />
                  <p className="text-sm text-muted-foreground">
                    {file ? <span className="text-primary font-medium">{file.name}</span> : "Click to upload PDF"}
                  </p>
                </div>
                <input 
                  type="file" 
                  className="hidden" 
                  accept=".pdf" 
                  onChange={e => setFile(e.target.files[0])} 
                />
              </label>
            </div>
          </div>
        </div>

        <button
          onClick={handleSubmit}
          disabled={loading}
          className="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground hover:bg-primary/90 h-11 px-8 w-full shadow-sm"
        >
          {loading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Uploading Research...
            </>
          ) : (
            "Submit Research Paper"
          )}
        </button>
      </div>
    </div>
  );
}