import { useEffect, useState } from "react";
import { supabase } from "../supabase/client";
import { FileText, Calendar, ChevronRight } from "lucide-react";

const statusStyles = {
  DRAFT: "bg-secondary text-secondary-foreground border-transparent",
  SUBMITTED: "bg-primary/10 text-primary border-primary/20",
  SUPERVISOR_APPROVED: "bg-accent text-accent-foreground border-transparent",
  HOD_APPROVED: "bg-emerald-500/10 text-emerald-600 border-emerald-500/20",
};

export default function StudentSubmissions() {
  const [research, setResearch] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    const { data: { user } } = await supabase.auth.getUser();

    const { data } = await supabase
      .from("research_projects")
      .select("id, title, status, created_at")
      .eq("student_id", user.id)
      .order("created_at", { ascending: false });

    setResearch(data || []);
    setLoading(false);
  }

  if (loading) return (
    <div className="flex items-center justify-center p-12">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
    </div>
  );

  return (
    // Changed: bg-white -> bg-card | shadow -> shadow-sm | border-gray-200 -> border-border
    <div className="bg-card rounded-xl border border-border shadow-sm overflow-hidden">
      <div className="p-5 border-b border-border bg-muted/30">
        <h3 className="font-semibold text-card-foreground flex items-center gap-2">
          <FileText className="w-4 h-4 text-primary" />
          My Research Submissions
        </h3>
      </div>

      {research.length === 0 ? (
        <div className="p-12 text-center">
          <FileText className="w-12 h-12 text-muted-foreground/20 mx-auto mb-4" />
          <p className="text-muted-foreground text-sm">No submissions found.</p>
        </div>
      ) : (
        <div className="divide-y divide-border">
          {research.map((r) => (
            <div 
              key={r.id} 
              className="p-4 flex justify-between items-center hover:bg-muted/50 transition-colors group cursor-pointer"
            >
              <div className="space-y-1">
                <p className="font-medium text-sm text-card-foreground group-hover:text-primary transition-colors">
                  {r.title}
                </p>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Calendar className="w-3 h-3" />
                  {new Date(r.created_at).toLocaleDateString(undefined, { 
                    year: 'numeric', 
                    month: 'short', 
                    day: 'numeric' 
                  })}
                </div>
              </div>

              <div className="flex items-center gap-4">
                <span
                  className={`px-2.5 py-0.5 text-[11px] rounded-full border font-semibold tracking-wide uppercase transition-colors ${
                    statusStyles[r.status] || "bg-secondary text-secondary-foreground"
                  }`}
                >
                  {r.status.replace("_", " ")}
                </span>
                <ChevronRight className="w-4 h-4 text-muted-foreground/50 group-hover:text-foreground transition-colors" />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}