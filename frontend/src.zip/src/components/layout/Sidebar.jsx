import { NavLink } from "react-router-dom";
import { 
  FileText, 
  BarChart, 
  CheckSquare, 
  Users, 
  PieChart, 
  Settings 
} from "lucide-react";

export default function Sidebar({ role }) {
  // Mapping roles to specific links and icons
  const menuConfig = {
    STUDENT: [
      { name: "Dashboard", path: "/student", icon: PieChart },
      { name: "My Research", path: "/student/research", icon: FileText },
      { name: "AI Reports", path: "/student/reports", icon: BarChart },
    ],
    FACULTY: [
      { name: "Pending", path: "/faculty/pending", icon: CheckSquare },
      { name: "Students", path: "/faculty/students", icon: Users },
    ],
    HOD: [
      { name: "Final Reviews", path: "/hod/approvals", icon: CheckSquare },
      { name: "Dept Stats", path: "/hod/stats", icon: BarChart },
    ],
    ADMIN: [
      { name: "Users", path: "/admin/users", icon: Users },
      { name: "Settings", path: "/admin/settings", icon: Settings },
    ]
  };

  const activeLinks = menuConfig[role] || [];

  return (
    <div className="w-64 bg-card border-r border-border text-card-foreground min-h-screen flex flex-col p-4">
      {/* Brand Section */}
      <div className="flex items-center gap-2 px-2 mb-8">
        <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
          <FileText className="text-primary-foreground w-5 h-5" />
        </div>
        <h2 className="text-xl font-bold tracking-tight">ResearchHub</h2>
      </div>

      {/* Navigation Links */}
      <nav className="space-y-1 flex-1">
        {activeLinks.map((item) => (
          <NavLink
            key={item.name}
            to={item.path}
            className={({ isActive }) => `
              flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors
              ${isActive 
                ? "bg-primary text-primary-foreground shadow-sm" 
                : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"}
            `}
          >
            <item.icon className="w-4 h-4" />
            {item.name}
          </NavLink>
        ))}
      </nav>

      {/* Footer (Optional) */}
      <div className="pt-4 border-t border-border">
        <p className="px-3 text-xs text-muted-foreground font-medium uppercase tracking-wider">
          {role} Account
        </p>
      </div>
    </div>
  );
}