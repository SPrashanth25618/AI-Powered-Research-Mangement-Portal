import { useEffect, useState } from "react";
import { LogOut, Bell, User, Sun, Moon } from "lucide-react";
import { supabase } from "../../supabase/client";

export default function Header({ title }) {
  const [isDark, setIsDark] = useState(false);

  // Initialize theme based on current class on document
  useEffect(() => {
    const isDarkMode = document.documentElement.classList.contains("dark");
    setIsDark(isDarkMode);
  }, []);

  const toggleTheme = () => {
    if (isDark) {
      document.documentElement.classList.remove("dark");
      localStorage.setItem("theme", "light");
      setIsDark(false);
    } else {
      document.documentElement.classList.add("dark");
      localStorage.setItem("theme", "dark");
      setIsDark(true);
    }
  };

  return (
    <header className="bg-card border-b border-border p-4 flex items-center justify-between sticky top-0 z-10 transition-colors duration-300">
      <h1 className="text-xl font-bold text-card-foreground tracking-tight">{title}</h1>
      
      <div className="flex items-center gap-2 md:gap-4">
        {/* THEME TOGGLE BUTTON */}
        <button
          onClick={toggleTheme}
          className="p-2 rounded-md hover:bg-accent text-muted-foreground hover:text-accent-foreground transition-colors"
          title="Toggle Theme"
        >
          {isDark ? (
            <Sun className="w-5 h-5 animate-in zoom-in duration-300" />
          ) : (
            <Moon className="w-5 h-5 animate-in zoom-in duration-300" />
          )}
        </button>

        <Bell className="w-5 h-5 text-muted-foreground cursor-pointer hover:text-primary transition-colors" />
        
        <div className="flex items-center gap-3 pl-3 border-l border-border">
          <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-primary-foreground">
            <User className="w-4 h-4" />
          </div>
          <button 
            onClick={() => supabase.auth.signOut()}
            className="hidden md:flex bg-destructive/10 text-destructive px-3 py-1.5 rounded-md text-sm font-medium hover:bg-destructive hover:text-destructive-foreground transition-all"
          >
            <LogOut className="w-4 h-4 mr-1" />
            Logout
          </button>
        </div>
      </div>
    </header>
  );
}