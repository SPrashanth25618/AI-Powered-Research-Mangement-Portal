import { useEffect, useState } from "react";
import { supabase } from "../supabase/client";
import Sidebar from "../components/layout/Sidebar";
import Header from "../components/layout/Header";

export default function HodDashboard() {
  const [research, setResearch] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [processingId, setProcessingId] = useState(null);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    try {
      setLoading(true);
      setError(null);

      const { data: { user }, error: userError } = await supabase.auth.getUser();
      
      if (userError || !user) {
        setError("Authentication failed. Please login again.");
        setLoading(false);
        return;
      }

      const { data: profile, error: profileError } = await supabase
        .from("users")
        .select("department_id, role")
        .eq("id", user.id)
        .single();

      if (profileError || !profile) {
        setError("Failed to load profile information.");
        setLoading(false);
        return;
      }

      // Fetch research projects that need HOD approval (SUPERVISOR_APPROVED status)
      const { data, error: fetchError } = await supabase
        .from("research_projects")
        .select("id, title, abstract, status, pdf_url, created_at, student_id")
        .eq("department_id", profile.department_id)
        .eq("status", "SUPERVISOR_APPROVED")
        .order("created_at", { ascending: false });

      if (fetchError) {
        setError("Failed to load research projects: " + fetchError.message);
        setResearch([]);
        setLoading(false);
        return;
      }

      // Fetch student details separately
      if (data && data.length > 0) {
        const studentIds = [...new Set(data.map(r => r.student_id).filter(Boolean))]; // Remove duplicates and null values
        
        if (studentIds.length > 0) {
          // First, check what columns exist in users table
          const { data: students, error: studentsError } = await supabase
            .from("users")
            .select("id, full_name") // Removed email, add other columns that exist
            .in("id", studentIds);

          if (studentsError) {
            console.error("Error fetching students:", studentsError);
            // Continue without student data
            setResearch(data.map(r => ({ ...r, student: null })));
          } else {
            // Merge student data
            const enrichedData = data.map(r => ({
              ...r,
              student: students?.find(s => s.id === r.student_id) || null
            }));
            setResearch(enrichedData);
          }
        } else {
          setResearch(data);
        }
      } else {
        setResearch([]);
      }

      setLoading(false);
    } catch (err) {
      setError("An unexpected error occurred: " + err.message);
      setLoading(false);
    }
  }

  async function approve(id) {
    try {
      setProcessingId(id);
      setError(null);

      const { data: { user }, error: userError } = await supabase.auth.getUser();
      
      if (userError || !user) {
        setError("Authentication failed. Please login again.");
        setProcessingId(null);
        return;
      }

      const { data, error } = await supabase
        .from("research_projects")
        .update({
          status: "HOD_APPROVED",
          last_action_by: user.id
        })
        .eq("id", id)
        .select();

      if (error) {
        setError("Failed to approve: " + error.message);
        console.error("Approval error:", error);
      } else if (data && data.length === 0) {
        setError("This research project may have already been processed.");
      } else {
        // Success - reload the list
        await load();
      }

      setProcessingId(null);
    } catch (err) {
      setError("An unexpected error occurred: " + err.message);
      setProcessingId(null);
    }
  }

  async function reject(id) {
    try {
      setProcessingId(id);
      setError(null);

      const { data: { user }, error: userError } = await supabase.auth.getUser();
      
      if (userError || !user) {
        setError("Authentication failed. Please login again.");
        setProcessingId(null);
        return;
      }

      const { data, error } = await supabase
        .from("research_projects")
        .update({
          status: "DRAFT",
          last_action_by: user.id
        })
        .eq("id", id)
        .select();

      if (error) {
        setError("Failed to reject: " + error.message);
        console.error("Rejection error:", error);
      } else if (data && data.length === 0) {
        setError("This research project may have already been processed.");
      } else {
        // Success - reload the list
        await load();
      }

      setProcessingId(null);
    } catch (err) {
      setError("An unexpected error occurred: " + err.message);
      setProcessingId(null);
    }
  }

  if (loading) {
    return (
      <div className="flex">
        <Sidebar role="HOD" />
        <div className="flex-1 bg-slate-100 min-h-screen">
          <Header title="HOD Approval Panel" />
          <div className="flex items-center justify-center h-64">
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
              <p className="text-gray-600">Loading research projects...</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex">
      <Sidebar role="HOD" />
      <div className="flex-1 bg-slate-100 min-h-screen">
        <Header title="HOD Approval Panel" />

        <div className="p-6">
          {error && (
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
              <p className="font-bold">Error</p>
              <p>{error}</p>
            </div>
          )}

          {research.length === 0 ? (
            <div className="bg-white rounded-lg shadow p-8 text-center">
              <svg
                className="mx-auto h-12 w-12 text-gray-400"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                />
              </svg>
              <h3 className="mt-2 text-lg font-medium text-gray-900">
                No pending research projects
              </h3>
              <p className="mt-1 text-sm text-gray-500">
                There are currently no research projects awaiting HOD approval.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                <p className="text-sm text-blue-800">
                  <strong>{research.length}</strong> research project{research.length !== 1 ? 's' : ''} awaiting final approval
                </p>
              </div>

              {research.map((r) => (
                <div key={r.id} className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex-1">
                      <h3 className="font-bold text-xl text-gray-900 mb-2">{r.title}</h3>
                      {r.student && (
                        <p className="text-sm text-gray-600 mb-2">
                          <span className="font-semibold">Student:</span> {r.student.full_name}
                        </p>
                      )}
                    </div>
                    <span className="bg-green-100 text-green-800 text-xs font-semibold px-3 py-1 rounded-full">
                      SUPERVISOR APPROVED
                    </span>
                  </div>

                  <p className="text-gray-700 mb-4">{r.abstract}</p>

                  {r.pdf_url && (
                    <a
                      href={r.pdf_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center text-blue-600 hover:text-blue-800 mb-4 font-medium"
                    >
                      <svg
                        className="w-4 h-4 mr-2"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                        />
                      </svg>
                      View PDF Document
                    </a>
                  )}

                  <div className="flex gap-3 mt-4 pt-4 border-t">
                    <button
                      onClick={() => approve(r.id)}
                      disabled={processingId === r.id}
                      className={`flex-1 bg-green-700 hover:bg-green-800 text-white font-medium px-6 py-2 rounded-lg transition-colors ${
                        processingId === r.id ? "opacity-50 cursor-not-allowed" : ""
                      }`}
                    >
                      {processingId === r.id ? (
                        <span className="flex items-center justify-center">
                          <svg className="animate-spin h-5 w-5 mr-2" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                          </svg>
                          Publishing...
                        </span>
                      ) : (
                        "✓ Approve & Publish"
                      )}
                    </button>

                    <button
                      onClick={() => reject(r.id)}
                      disabled={processingId === r.id}
                      className={`flex-1 bg-red-600 hover:bg-red-700 text-white font-medium px-6 py-2 rounded-lg transition-colors ${
                        processingId === r.id ? "opacity-50 cursor-not-allowed" : ""
                      }`}
                    >
                      {processingId === r.id ? "Processing..." : "✗ Send Back for Revisions"}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}