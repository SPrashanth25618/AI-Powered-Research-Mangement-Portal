import { useEffect, useState } from "react";
import { supabase } from "../supabase/client";
import Sidebar from "../components/layout/Sidebar";
import Header from "../components/layout/Header";

export default function AdminDashboard() {
  const [faculty, setFaculty] = useState([]);
  const [hods, setHods] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [stats, setStats] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadAll();
  }, []);

  async function loadAll() {
    setLoading(true);

    const { data: fac } = await supabase
      .from("users")
      .select("id, full_name")
      .eq("role", "FACULTY");

    const { data: hod } = await supabase
      .from("users")
      .select("id, full_name")
      .eq("role", "HOD");

    const { data: depts } = await supabase
      .from("departments")
      .select("id,name,hod_id,supervisor_id");

    const { data: stat } = await supabase.rpc("get_admin_stats");

    setFaculty(fac || []);
    setHods(hod || []);
    setDepartments(depts || []);
    setStats(stat || {});
    setLoading(false);
  }

  async function assignHOD(deptId, hodId) {
    await supabase.from("departments").update({ hod_id: hodId }).eq("id", deptId);
    loadAll();
  }

  async function assignSupervisor(deptId, facultyId) {
    await supabase.from("departments").update({ supervisor_id: facultyId }).eq("id", deptId);
    loadAll();
  }

  if (loading) return <div className="p-10">Loading Admin Dashboard...</div>;

  return (
    <div className="flex">
      <Sidebar role="ADMIN" />

      <div className="flex-1 bg-slate-100 min-h-screen">
        <Header title="Admin Dashboard" />

        {/* Analytics */}
        <div className="p-6 grid grid-cols-4 gap-4">
          <Stat label="Users" value={stats.total_users} />
          <Stat label="Departments" value={stats.total_departments} />
          <Stat label="Research" value={stats.total_research} />
          <Stat label="Publications" value={stats.total_publications} />
        </div>

        {/* Departments */}
        <div className="p-6">
          <h2 className="font-bold text-lg mb-4">Departments</h2>
          <div className="grid grid-cols-2 gap-4">
            {departments.map((d) => (
              <div key={d.id} className="bg-white p-4 rounded shadow">
                <h3 className="font-semibold">{d.name}</h3>

                <div className="mt-3">
                  <label className="text-sm">Assign HOD</label>
                  <select
                    className="border p-2 w-full"
                    value={d.hod_id || ""}
                    onChange={(e) => assignHOD(d.id, e.target.value)}
                  >
                    <option value="">Select HOD</option>
                    {hods.map((h) => (
                      <option key={h.id} value={h.id}>
                        {h.full_name}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="mt-3">
                  <label className="text-sm">Assign Faculty Supervisor</label>
                  <select
                    className="border p-2 w-full"
                    value={d.supervisor_id || ""}
                    onChange={(e) => assignSupervisor(d.id, e.target.value)}
                  >
                    <option value="">Select Faculty</option>
                    {faculty.map((f) => (
                      <option key={f.id} value={f.id}>
                        {f.full_name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Faculty & HOD List */}
        <div className="p-6 grid grid-cols-2 gap-6">
          <div className="bg-white p-4 rounded shadow">
            <h2 className="font-bold mb-3">Faculty Members</h2>
            {faculty.map((f) => (
              <div key={f.id} className="border p-2 rounded mb-2">
                {f.full_name}
              </div>
            ))}
          </div>

          <div className="bg-white p-4 rounded shadow">
            <h2 className="font-bold mb-3">HODs</h2>
            {hods.map((h) => (
              <div key={h.id} className="border p-2 rounded mb-2">
                {h.full_name}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

/* KPI Card */
function Stat({ label, value }) {
  return (
    <div className="bg-white p-4 rounded shadow text-center">
      <p className="text-gray-500 text-sm">{label}</p>
      <h2 className="text-2xl font-bold">{value || 0}</h2>
    </div>
  );
}
