import { useEffect, useState } from "react";
import { supabase } from "../supabase/client";
import Sidebar from "../components/layout/Sidebar";
import Header from "../components/layout/Header";
import StatCard from "../components/ui/Statcard";
import SubmitResearch from "../components/SubmitResearch.jsx";
import { FileText, CheckCircle, BarChart3 } from "lucide-react";
import StudentSubmissions from "../components/StudentSubmissions.jsx";

export default function StudentDashboard() {
  const [stats, setStats] = useState({
    total: 0,
    approved: 0,
    plagiarism: 0
  });

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadStats();
  }, []);

  async function loadStats() {
    const { data: { user } } = await supabase.auth.getUser();

    const { data, error } = await supabase
      .from("research_projects")
      .select("status, plagiarism_score")
      .eq("student_id", user.id);

    if (error) {
      setLoading(false);
      return;
    }

    const total = data.length;
    const approved = data.filter(r => r.status === "HOD_APPROVED").length;

    const scores = data
      .filter(r => r.plagiarism_score !== null)
      .map(r => r.plagiarism_score);

    const avg =
      scores.length > 0
        ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length)
        : 0;

    setStats({
      total,
      approved,
      plagiarism: avg
    });

    setLoading(false);
  }

  if (loading) {
    return (
      <div className="flex bg-background text-foreground min-h-screen">
        <Sidebar role="STUDENT" />
        <div className="flex-1 p-10 flex items-center justify-center">
          <div className="animate-pulse text-muted-foreground">Loading dashboard...</div>
        </div>
      </div>
    );
  }

  return (
    // Changed: bg-gray-50 -> bg-background (uses your theme variables)
    <div className="flex min-h-screen bg-background text-foreground">
      <Sidebar role="STUDENT" />

      <div className="flex-1 flex flex-col">
        <Header title="Student Dashboard" />

        <main className="flex-1 p-6 space-y-8">
          {/* Stats Section */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <StatCard 
              label="My Submissions"
              value={stats.total}
              icon={FileText}
              color="primary" // Changed to use your theme's primary color
            />
            <StatCard 
              label="Approved"
              value={stats.approved}
              icon={CheckCircle}
              color="emerald" 
            />
            <StatCard 
              label="Plagiarism Avg"
              value={`${stats.plagiarism}%`}
              icon={BarChart3}
              color="destructive" // Standard shadcn variable for alerts/errors
            />
          </div>

          {/* New Research Section with themed borders/text */}
          <section className="rounded-xl border bg-card p-6 shadow-sm">
            <div className="mb-6">
              <h2 className="text-2xl font-semibold tracking-tight text-card-foreground">
                Submit New Research
              </h2>
              <p className="text-muted-foreground text-sm">
                Upload your research paper for review and approval
              </p>
            </div>
            
            <SubmitResearch onSuccess={loadStats} />
          </section>

          {/* Submissions List Section */}
          <section className="space-y-4">
            <h3 className="text-lg font-medium px-1">Recent History</h3>
            <StudentSubmissions />
          </section>
        </main>
      </div>
    </div>
  );
}