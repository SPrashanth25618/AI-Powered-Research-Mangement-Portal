import { useEffect, useState } from "react";
import { supabase } from "../supabase/client";
import Sidebar from "../components/layout/Sidebar";
import Header from "../components/layout/Header";

export default function FacultyDashboard() {
  const [research, setResearch] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [processingId, setProcessingId] = useState(null);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    try {
      setLoading(true);
      setError(null);

      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) {
        setError("Not authenticated");
        setLoading(false);
        return;
      }

      // Get faculty department
      const { data: profile, error: profileError } = await supabase
        .from("users")
        .select("department_id")
        .eq("id", user.id)
        .single();

      if (profileError || !profile?.department_id) {
        setError("Unable to load faculty department");
        setLoading(false);
        return;
      }

      // 🔥 FETCH ONLY SUBMITTED PAPERS
      const { data, error: fetchError } = await supabase
        .from("research_projects")
        .select("id,title,abstract,status,pdf_url,created_at,student_id")
        .eq("department_id", profile.department_id)
        .eq("status", "SUBMITTED")
        .order("created_at", { ascending: false });

      if (fetchError) {
        setError(fetchError.message);
        setResearch([]);
        setLoading(false);
        return;
      }

      if (data.length > 0) {
        const ids = [...new Set(data.map((r) => r.student_id))];

        const { data: students } = await supabase
          .from("users")
          .select("id, full_name")
          .in("id", ids);

        const enriched = data.map((r) => ({
          ...r,
          student: students?.find((s) => s.id === r.student_id),
        }));

        setResearch(enriched);
      } else {
        setResearch([]);
      }

      setLoading(false);
    } catch (err) {
      setError(err.message);
      setLoading(false);
    }
  }

  async function approve(id) {
    try {
      setProcessingId(id);
      setError(null);

      const {
        data: { user },
      } = await supabase.auth.getUser();

      const { error } = await supabase
        .from("research_projects")
        .update({
          status: "SUPERVISOR_APPROVED",
          last_action_by: user.id,
        })
        .eq("id", id); // 🔥 only id filter

      if (error) {
        console.error(error);
        setError(error.message);
      } else {
        await load();
      }
    } finally {
      setProcessingId(null);
    }
  }

  async function reject(id) {
    try {
      setProcessingId(id);
      setError(null);

      const {
        data: { user },
      } = await supabase.auth.getUser();

      const { error } = await supabase
        .from("research_projects")
        .update({
          status: "DRAFT",
          last_action_by: user.id,
        })
        .eq("id", id)
        .eq("status", "SUBMITTED");

      if (error) {
        setError(error.message);
      } else {
        await load();
      }
    } finally {
      setProcessingId(null);
    }
  }

  if (loading) {
    return (
      <div className="flex">
        <Sidebar role="FACULTY" />
        <div className="flex-1 p-10">Loading…</div>
      </div>
    );
  }

  return (
    <div className="flex">
      <Sidebar role="FACULTY" />
      <div className="flex-1 bg-slate-100 min-h-screen">
        <Header title="Faculty Review Panel" />

        <div className="p-6">
          {error && (
            <div className="bg-red-100 text-red-700 p-4 rounded mb-4">
              {error}
            </div>
          )}

          {research.length === 0 ? (
            <div className="bg-white p-8 rounded shadow text-center">
              No research papers waiting for approval
            </div>
          ) : (
            research.map((r) => (
              <div key={r.id} className="bg-white p-6 rounded shadow mb-4">
                <h3 className="text-xl font-bold">{r.title}</h3>
                <p className="text-sm text-gray-600 mb-1">
                  Student: {r.student?.full_name}
                </p>

                <p className="my-3">{r.abstract}</p>

                {r.pdf_url && (
                  <a
                    href={r.pdf_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-600 font-semibold"
                  >
                    View PDF
                  </a>
                )}

                <div className="mt-4 flex gap-4">
                  <button
                    onClick={() => approve(r.id)}
                    disabled={processingId === r.id}
                    className="bg-green-600 text-white px-4 py-2 rounded"
                  >
                    {processingId === r.id ? "Processing..." : "Approve"}
                  </button>

                  <button
                    onClick={() => reject(r.id)}
                    disabled={processingId === r.id}
                    className="bg-red-600 text-white px-4 py-2 rounded"
                  >
                    {processingId === r.id ? "Processing..." : "Reject"}
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
